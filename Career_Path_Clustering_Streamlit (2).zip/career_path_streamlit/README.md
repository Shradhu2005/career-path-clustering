# Career Path Clustering — Streamlit Web App

This app turns the Career Path Clustering notebook into a browser-based demo. It uses TF-IDF text features, PCA, and K-Means clustering, displays cluster sizes and keywords, and lets a visitor test a resume.

## Files
- `app.py` — Streamlit website
- `requirements.txt` — Python packages
- `Project_4_Career_Path_Clustering.ipynb` — original notebook for reference (if included in this folder)

## Run locally on Windows
1. Install Python 3.10 or newer from https://www.python.org/downloads/ and select **Add Python to PATH** during installation.
2. Extract this ZIP into a folder.
3. Open that folder in VS Code.
4. Open **Terminal → New Terminal**.
5. Run:
   ```bash
   python -m venv .venv
   ```
6. Activate it:
   ```powershell
   .venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks activation, use Command Prompt and run `.venv\Scripts\activate.bat` instead.
7. Install packages:
   ```bash
   python -m pip install -r requirements.txt
   ```
8. Start the app:
   ```bash
   python -m streamlit run app.py
   ```
9. Your browser opens a local address, usually `http://localhost:8501`.
10. Upload your `resume.csv` dataset in the left sidebar. It is not bundled because the notebook expects it as a separate file.

## Publish a public URL with Streamlit Community Cloud
1. Create/sign in to GitHub at https://github.com/.
2. Create a **public** repository, for example `career-path-clustering`.
3. Upload `app.py`, `requirements.txt`, and `README.md` to the repository. Do not upload private resumes or personal data.
4. Go to https://share.streamlit.io/ and sign in with GitHub.
5. Choose **Create app**, select your repository and branch, and set the main file path to `app.py`.
6. Click **Deploy**. Wait for the build to finish; Streamlit will show a public URL like `https://your-app-name.streamlit.app`.
7. Open that URL in a private/incognito window to test it. Visitors must upload the dataset themselves unless you separately configure a safe public dataset.

## Dataset notes
The app expects a CSV with a `Resume` column, or one or more of `skills`, `career_objective`, `experience`, `education`, `description`. Upload your original `resume.csv` from the sidebar when the app opens.

## Privacy
Resume files may contain personal information. For a public demo, use synthetic/sample resumes or a dataset you are permitted to share. Do not upload real people's private resumes to a public repository.
