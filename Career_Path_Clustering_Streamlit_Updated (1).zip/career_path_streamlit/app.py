import io
import re
from collections import Counter

import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.figure_factory as ff
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sklearn.neighbors import NearestNeighbors

st.set_page_config(page_title="Career Path Clustering", page_icon="🧭", layout="wide")
CAREER_SKILLS = {
    "Data Science": ["python", "machine learning", "data analysis", "pandas", "numpy", "statistics", "sql", "tensorflow", "power bi", "deep learning", "scikit learn"],
    "Web Development": ["html", "css", "javascript", "react", "angular", "node.js", "flask", "django", "php", "api", "frontend", "backend"],
    "HR / Human Resources": ["recruitment", "communication", "employee relations", "talent acquisition", "payroll", "training", "human resources", "interviewing", "onboarding"],
}

def clean_text(value):
    txt = re.sub(r"[^a-zA-Z ]", " ", str(value)).lower()
    return " ".join(w for w in txt.split() if w not in ENGLISH_STOP_WORDS and len(w) > 1)

def read_resume(uploaded_file):
    name, data = uploaded_file.name.lower(), uploaded_file.getvalue()
    if name.endswith(".txt"):
        return data.decode("utf-8", errors="ignore")
    if name.endswith(".pdf"):
        from pypdf import PdfReader
        return "\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(data)).pages)
    if name.endswith(".docx"):
        from docx import Document
        return "\n".join(p.text for p in Document(io.BytesIO(data)).paragraphs)
    raise ValueError("Upload a PDF, DOCX, or TXT resume.")

def prepare_dataset(source):
    df = source.copy()
    if "Resume" not in df.columns:
        cols = [c for c in ["skills", "career_objective", "experience", "education", "description"] if c in df.columns]
        if not cols:
            raise ValueError("CSV must contain 'Resume' or one of: skills, career_objective, experience, education, description.")
        df["Resume"] = df[cols].fillna("").astype(str).agg(" ".join, axis=1)
    df["Resume"] = df["Resume"].fillna("").astype(str)
    df = df[df["Resume"].str.strip().ne("")].reset_index(drop=True)
    if len(df) < 3:
        raise ValueError("At least 3 non-empty resumes are required.")
    return df

st.title("🧭 Career Path Clustering")
st.write("Resume analysis using NLP, TF-IDF and machine-learning clustering.")
with st.sidebar:
    st.header("Dataset")
    dataset_file = st.file_uploader("Upload resume.csv", type=["csv"])
    k = st.slider("Number of K-Means clusters", 2, 10, 5)
    st.caption("CSV needs a Resume column, or columns such as skills and career_objective.")

if dataset_file is None:
    st.info("Upload your resume.csv dataset from the sidebar to view the project outputs.")
    st.markdown("""
    **Project workflow:** Dataset → Cleaning → TF-IDF → PCA → Clustering → Evaluation → Career insights.

    **Note:** The ZIP does not include the resume.csv dataset. You must upload it when opening the app.
    """)
    st.stop()

try:
    raw = pd.read_csv(dataset_file)
    df = prepare_dataset(raw)
    df["cleaned_resume"] = df["Resume"].apply(clean_text)
    df = df[df["cleaned_resume"].str.strip().ne("")].reset_index(drop=True)
    if len(df) < 3:
        st.error("Not enough usable resumes after cleaning.")
        st.stop()

    vectorizer = TfidfVectorizer(max_features=2000)
    X_sparse = vectorizer.fit_transform(df["cleaned_resume"])
    X = X_sparse.toarray()
    n_components = min(50, X.shape[0] - 1, X.shape[1] - 1)
    if n_components < 1:
        st.error("Not enough distinct words/features. Please upload a more varied dataset.")
        st.stop()
    pca = PCA(n_components=n_components, random_state=42)
    X_pca = pca.fit_transform(X)
    actual_k = min(k, len(df) - 1)
    km = KMeans(n_clusters=actual_k, random_state=42, n_init=10)
    df["Cluster"] = km.fit_predict(X_pca)
    terms = vectorizer.get_feature_names_out()

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Usable resumes", len(df))
    m2.metric("K-Means clusters", actual_k)
    m3.metric("TF-IDF features", X_sparse.shape[1])
    m4.metric("Raw dataset rows", len(raw))

    tabs = st.tabs(["📁 Data Preview", "🧹 Cleaning & EDA", "📊 Skills Analysis", "🧩 Clustering", "📈 Evaluation", "💡 Career Insights", "📄 Test Resume"])

    with tabs[0]:
        st.subheader("Dataset Preview")
        st.dataframe(raw.head(20), use_container_width=True)
        st.caption(f"Original dataset: {len(raw)} rows × {len(raw.columns)} columns")
        st.subheader("Processed Dataset")
        st.dataframe(df[["Resume", "cleaned_resume", "Cluster"]].head(20), use_container_width=True)
        st.download_button("Download clustered dataset (CSV)", df.to_csv(index=False).encode("utf-8"), "career_path_clusters.csv", "text/csv")

    with tabs[1]:
        st.subheader("Data Cleaning & Preprocessing")
        a, b, c = st.columns(3)
        a.metric("Rows in uploaded data", len(raw))
        b.metric("Non-empty resumes", len(df))
        c.metric("Rows removed / unusable", max(0, len(raw)-len(df)))
        st.write("Cleaning steps: missing resume text handled → text converted to lowercase → punctuation/numbers removed → common English stop words removed.")
        st.dataframe(df[["Resume", "cleaned_resume"]].head(15), use_container_width=True)
        lengths = df["Resume"].str.split().str.len().rename("Word count").to_frame()
        st.plotly_chart(px.histogram(lengths, x="Word count", nbins=30, title="Resume Length Distribution"), use_container_width=True)

    with tabs[2]:
        st.subheader("Skills / Frequent Word Analysis")
        all_words = " ".join(df["cleaned_resume"]).split()
        freq = Counter(all_words)
        top = pd.DataFrame(freq.most_common(15), columns=["Skill / Word", "Frequency"])
        if not top.empty:
            st.plotly_chart(px.bar(top, x="Skill / Word", y="Frequency", title="Top 15 Frequent Skills / Words"), use_container_width=True)
            st.plotly_chart(px.treemap(top, path=["Skill / Word"], values="Frequency", title="Top Skills Treemap"), use_container_width=True)
            st.dataframe(top, use_container_width=True)
        else:
            st.warning("No frequent words were found.")

    with tabs[3]:
        st.subheader("K-Means Clustering")
        counts = df["Cluster"].value_counts().sort_index().rename_axis("Cluster").reset_index(name="Resume count")
        left, right = st.columns(2)
        left.plotly_chart(px.bar(counts, x="Cluster", y="Resume count", title="Number of Resumes in Each K-Means Cluster"), use_container_width=True)
        right.plotly_chart(px.scatter(x=X_pca[:, 0], y=X_pca[:, 1] if X_pca.shape[1] > 1 else np.zeros(len(df)), color=df["Cluster"].astype(str), title="K-Means Cluster Visualization", labels={"x":"PCA 1","y":"PCA 2","color":"Cluster"}), use_container_width=True)
        st.subheader("Elbow Method")
        max_k = min(10, len(df)-1)
        ks = list(range(2, max_k+1))
        inertias = []
        for n in ks:
            inertias.append(KMeans(n_clusters=n, random_state=42, n_init=10).fit(X_pca).inertia_)
        st.plotly_chart(px.line(x=ks, y=inertias, markers=True, labels={"x":"Number of clusters (K)","y":"WCSS / Inertia"}, title="Elbow Method for Optimal K"), use_container_width=True)
        st.caption("Look for the bend ('elbow') in the curve; it is a guide for selecting K.")
        st.subheader("t-SNE Visualization")
        if len(df) >= 4:
            tsne_perplexity = min(30, len(df) - 1)
            tsne_points = TSNE(n_components=2, random_state=42, perplexity=tsne_perplexity, init="pca", learning_rate="auto").fit_transform(X_pca)
            st.plotly_chart(px.scatter(x=tsne_points[:, 0], y=tsne_points[:, 1], color=df["Cluster"].astype(str),
                                       title="Career Path Clusters (t-SNE)", labels={"x":"t-SNE 1","y":"t-SNE 2","color":"Cluster"}),
                            use_container_width=True)
        else:
            st.caption("At least 4 resumes are needed for t-SNE visualization.")

        st.subheader("DBSCAN Clustering")
        eps = st.slider("DBSCAN eps", 0.1, 5.0, 1.5, 0.1)
        min_samples = st.slider("DBSCAN min_samples", 2, 10, 5)
        db_labels = DBSCAN(eps=eps, min_samples=min_samples).fit_predict(X_pca)
        db_counts = pd.Series(db_labels).value_counts().sort_index().rename_axis("DBSCAN label (-1 = noise)").reset_index(name="Resume count")
        st.dataframe(db_counts, use_container_width=True)
        st.plotly_chart(px.scatter(x=X_pca[:,0], y=X_pca[:,1] if X_pca.shape[1]>1 else np.zeros(len(df)), color=pd.Series(db_labels).astype(str), title="DBSCAN Cluster Visualization", labels={"x":"PCA 1","y":"PCA 2","color":"DBSCAN label"}), use_container_width=True)
        st.subheader("Hierarchical Clustering")
        if len(df) >= 3:
            hc_k = min(actual_k, len(df)-1)
            hc = AgglomerativeClustering(n_clusters=hc_k, linkage="ward").fit_predict(X_pca)
            st.plotly_chart(px.scatter(x=X_pca[:,0], y=X_pca[:,1] if X_pca.shape[1]>1 else np.zeros(len(df)), color=pd.Series(hc).astype(str), title="Hierarchical Clustering Visualization", labels={"x":"PCA 1","y":"PCA 2","color":"Cluster"}), use_container_width=True)
            st.caption("Hierarchical clusters are shown as groups. A full dendrogram can be computationally heavy for large datasets.")

    with tabs[4]:
        st.subheader("Clustering Evaluation")
        labels = df["Cluster"].to_numpy()
        unique = np.unique(labels)
        if 1 < len(unique) < len(df):
            sil = silhouette_score(X_pca, labels)
            dbi = davies_bouldin_score(X_pca, labels)
            x1, x2 = st.columns(2)
            x1.metric("Silhouette Score", f"{sil:.3f}")
            x2.metric("Davies-Bouldin Index", f"{dbi:.3f}")
            st.write("Silhouette score: closer to +1 generally indicates better-separated clusters.")
            st.write("Davies-Bouldin Index: lower values generally indicate more compact and separated clusters.")
        else:
            st.warning("Evaluation scores cannot be calculated for the current cluster labels.")

    with tabs[5]:
        st.subheader("Cluster Keywords & Career Insights")
        for cluster_id in sorted(df["Cluster"].unique()):
            members = np.where(labels == cluster_id)[0]
            mean_vec = X_sparse[members].mean(axis=0).A1
            top_idx = mean_vec.argsort()[-10:][::-1]
            keywords = [terms[i] for i in top_idx if mean_vec[i] > 0]
            with st.expander(f"Cluster {cluster_id} — {len(members)} resumes", expanded=True):
                st.write("**Important keywords:** " + (", ".join(keywords) if keywords else "No prominent keywords found."))
                st.caption("Cluster numbers are machine-generated groups, not confirmed job titles.")
        st.subheader("Career Skill Dictionary")
        st.write("The following built-in skill groups provide simple indicative suggestions.")
        for role, skills in CAREER_SKILLS.items():
            st.write(f"**{role}:** {', '.join(skills)}")

    with tabs[6]:
        st.subheader("Test a Resume")
        st.write("Upload a PDF, DOCX or TXT resume, or paste resume text.")
        up = st.file_uploader("Upload resume", type=["pdf","docx","txt"], key="resume_test")
        pasted = st.text_area("Or paste resume text", height=160)
        if st.button("Analyze Resume", type="primary"):
            try:
                content = read_resume(up) if up else pasted
                cleaned = clean_text(content)
                if not cleaned:
                    st.warning("Please provide readable resume text.")
                else:
                    vec = vectorizer.transform([cleaned]).toarray()
                    predicted = int(km.predict(pca.transform(vec))[0])
                    st.success(f"Predicted closest cluster: {predicted}")
                    st.metric("Resume word count", len(content.split()))
                    low = content.lower()
                    matches = {role:[s for s in skills if re.search(r"(?<!\w)"+re.escape(s)+r"(?!\w)", low)] for role,skills in CAREER_SKILLS.items()}
                    matches = {r:s for r,s in matches.items() if s}
                    if matches:
                        for role, skills in matches.items():
                            st.write(f"**{role}:** {', '.join(skills)}")
                        best_role, found = max(matches.items(), key=lambda x:len(x[1]))
                        missing = [s for s in CAREER_SKILLS[best_role] if s not in found][:5]
                        st.write(f"**Skills to consider for {best_role}:** {', '.join(missing) if missing else 'Continue developing relevant skills.'}")
                    else:
                        st.info("No skills from the built-in skill dictionary were detected.")
                    members = np.where(labels == predicted)[0]
                    mean_vec = X_sparse[members].mean(axis=0).A1
                    idx = mean_vec.argsort()[-10:][::-1]
                    st.write("**Keywords associated with this cluster:** " + ", ".join(terms[i] for i in idx if mean_vec[i] > 0))
                    st.caption("This is an experimental cluster match, not a verified job title or hiring recommendation.")
            except Exception as exc:
                st.error(f"Could not analyze resume: {exc}")

except Exception as exc:
    st.error(f"Could not process the dataset: {exc}")
    st.info("Check that the CSV contains a Resume column or supported text columns, and at least 3 usable resumes.")
